document.forms.openSistem.addEventListener('submit', async (event) => {
    event.preventDefault()
    let link = await fetch('/php.php', {
        method: 'POST',
        body: new FormData(document.getElementById('top'))
    })
    let result = await link.json();
    await console.log(result)
    await alert(result)
});





[...document.querySelectorAll('#Open')].map((el) => {
    el.addEventListener('click', () => {
        document.getElementById('Dialog').toggleAttribute('open')
    })
})


