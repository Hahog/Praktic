<?php
/*if(isset($_GET["Login"]) && isset($_GET["Password"])) {
    $conn = mysqli_connect("localhost", "root", "", "sait");
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    $Login = $conn->real_escape_string($_GET["Login"]);
    $Password = $conn->real_escape_string($_GET["Password"]);
    $sql = "SELECT Login, Password FROM Users WHERE Login = '$Login' AND Password = '$Password'";
    if( $result = $conn->query($sql)){
        print_r( $result);
        if($result->num_rows > 0) {
            setcookie('Reg', true, 0, "/");
            echo true;
        } else {
            setcookie('Reg', false, 0, "/");
        }
    } else{
        echo "Ошибка: " . $conn->error;
    }
    exit('<meta id="Meta" http-equiv="refresh" content="0; url=index.html" />');
}*/

if($_POST) {
    $res = $_POST;
    $Login = $res["Login"];
    $Password = $res["Password"];
    $conn = mysqli_connect("localhost", "root", "", "sait");
    if($conn->connect_error){
        die("Ошибка: " . $conn->connect_error);
    }
    $sql = "SELECT Login, Password FROM Users WHERE Login = '$Login' AND Password = '$Password'";
    if( $result = $conn->query($sql)){
        if($result->num_rows > 0) {
            echo json_encode(true, JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode(false, JSON_UNESCAPED_UNICODE);
        }
    } else{
        echo "Ошибка: " . $conn->error;
    }
}

?>